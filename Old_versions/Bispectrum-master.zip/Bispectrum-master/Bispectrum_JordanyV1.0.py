##############################################################################
## This script is test for bispectrum with gaunt integral.
## Authors: Jordany Vieira de Melo and Karin Fornazier
### Email: jordanyv@gmail.com
## Version: 2.0
## Date: 11-13-2018
#############################################################################


from scipy.integrate import quad
from scipy.interpolate import interp1d
from scipy.stats import norm
import matplotlib
import numpy as np
import healpy as hp
import matplotlib.pyplot as plt
import matplotlib.cm as cm
import matplotlib.mlab as mlab
from astropy.io import fits
from math import pi, sin, cos, sqrt, log, floor
from sympy.physics.wigner import gaunt


###############################################################################################################################
# B_ell = bispectrum function according paper https://arxiv.org/pdf/1509.08107.pdf equation (2.3). Vector function.
# alm1 = alm for l_1 and m_1 from https://arxiv.org/pdf/1509.08107.pdf equation (2.3).
# alm2 = alm for l_2 and m_2 from https://arxiv.org/pdf/1509.08107.pdf equation (2.3).
# alm3 = alm for l_3 and m_3 from https://arxiv.org/pdf/1509.08107.pdf equation (2.3).
# l = number of multipoles, one l because this test are for equilateral bispectrum.
# c_i = variable which will recieve the sum over loop under m's from paper https://arxiv.org/pdf/1509.08107.pdf equation (2.3).
###############################################################################################################################


####################################################################################################################################
# Loop over m_1, m_2, m_3.                                                                                                         #
# Use append for B_ell recieve the value reserved on c_i and use gaunt because we need to calculate the gaunt integral             #
# and this function make the calculate of the integral. And we multiply by 2, in end of the loop, because a_lm is equal to a_l(-m).#
####################################################################################################################################

#######################################################################################
# The comment below is an exemple to be used with the alm's of a map.
########################################################################################

#####################################################################################
#B_ell=[]
#alm1=
#alm2=
#alm3=
#l=
#c_i=0
#for i in range(0, l+1):
#    if i == 0:
#        B_ell.append((gaunt(0,0,0,0,0,0))*abs(alm1[0])*abs(alm2[0])*abs(alm3[0]))
#    if i != 0:
#        c_i += (gaunt(i,i,i,i,i,i))*(abs(alm1[i])*abs(alm2[i])*abs(alm3[i]))
#        for j in range(1, i+1):
#            h=hp.Alm.getidx(l, i, j)
#            for k in range(1, i+1)
#                m=hp.Alm.getidx(l, i, k)
#                c_i += (gaunt(i,i,i,i,h,m)*abs(alm1[i])*abs(alm2[h])*abs(alm3[m]))
#        B_ell.append(c_i)
#    m=0
#    c_i=0
#B_ell
#######################################################################################

######################################################################################
# Now generate a thermal noise map
######################################################################################

NSIDE = 64
mu, sigma = 0, 0.1 # mean and standard deviation
#planck_IQU_SMICA = hp.read_map('COM_CMB_IQU-smica_1024_R2.02_full.fits')
#alm1=hp.map2alm(planck_IQU_SMICA, lmax=1024)

mapa = hp.read_map('foreground_cube_21cm_fore.fits')
alm1=hp.map2alm(mapa)

######################################################################################
# Then we use the code comment above with only alm1, because the test is for equilateral bispectrum.
######################################################################################

B_ell=[]
alm1=hp.map2alm(mapa)
l=191
c_i=0
for i in range(0, l+1):
    if i == 0:
        B_ell.append((gaunt(0,0,0,0,0,0))*np.real(alm1[0])*np.real(alm1[0])*np.real(alm1[0]))
    if i != 0:
        c_i += (gaunt(i,i,i,0,0,0))*(np.real(alm1[i])*np.real(alm1[i])*np.real(alm1[i]))
        for j in range(1, i+1):
            h=hp.Alm.getidx(l, i, j)
            for k in range(1, i+1):
                m=hp.Alm.getidx(l, i, k)
                c_i += (gaunt(i,i,i,i,h,m)*2*np.real(alm1[i])*np.real(alm1[h])*np.real(alm1[m]))
        B_ell.append(c_i)
    h=0
    m=0
    c_i=0
B_ell

###########################################################################################
# Now we plot the Bl's x l, in normal scale and log scale
##############################################################################################

bl_test = B_ell
ell = np.arange(len(bl_test))
#bl_testl = (ell * (ell + 1) * bl_test / (2*pi))

plt.rcParams['figure.figsize'] = (12,8)

plt.xlabel('$\ell$')
plt.ylabel('$B_\ell$')
plt.plot(ell, bl_test)
plt.show()

plt.rcParams['figure.figsize'] = (12,8)

plt.xlabel('$\ell$')
plt.ylabel('$B_\ell$')
plt.plot(ell, bl_test)
plt.xscale('log')
plt.show()
