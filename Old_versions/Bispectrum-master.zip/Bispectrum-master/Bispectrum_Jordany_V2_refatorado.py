#####################################################################################################################
#####################################################################################################################
###                                       Bispectrum Algorithm version 0.01                                     #####
###                                                                                                             ##### 
###     Algorithm based on:                                                                                     #####  
### Komatsu Thesis --> https://wwwmpa.mpa-garching.mpg.de/~komatsu/phdthesis.html                               ##### 
### Bucher et al  -->  https://arxiv.org/pdf/1509.08107.pdf                                                     #####
### Authors Jordany Vieira de Melo and Karin Fornazier                                                          #####
### Supervisor: F.B. Abdalla                                                                                    #####
### DATE: January 2019                                                                                          #####
#####################################################################################################################
#####################################################################################################################
# l = number of multipoles, one l because this test are for equilateral bispectrum.                             ##### 
# c_i = variable which will recieve the sum over loop under m's from paper                                      #####
# https://arxiv.org/pdf/1509.08107.pdf equation (2.3).                                                          #####
#####################################################################################################################
# Loop over m_1, m_2, m_3.                                                                                       ####
# Use append for B_ell recieve the value reserved on c_i. Here we use the gaunt function for calculate the       ####
# gaunt integral of equation (2.3) in the paper https://arxiv.org/pdf/1509.08107.pdf.                            ####   
#####################################################################################################################


from scipy.integrate import quad
from scipy.interpolate import interp1d
from scipy.stats import norm
import matplotlib
import numpy as np
import healpy as hp
import matplotlib.pyplot as plt
import matplotlib.cm as cm
import matplotlib.mlab as mlab
from astropy.io import fits
from math import pi, sin, cos, sqrt, log, floor
from sympy.physics.wigner import gaunt

###################################################
###########  Map -- Thermal Noise #################
################################################### 

##Definitions 
NSIDE = 64 #For thermal noise test.
mu, sigma = 0, 0.1 # mean and standard deviation

## Map - generating the Thermal Noise
mapa = np.random.normal(mu, sigma, hp.nside2npix(NSIDE))

## alm1 = variable described at Eq 2.3 in https://arxiv.org/pdf/1509.08107.pdf 
## getting alm from map
alm1=hp.map2alm(mapa, lmax=30)


### B_ell 
B_ell=[]
alm1=hp.map2alm(mapa[0,:], lmax=30)
l= 30
c_i=0

###################################################
def gauntFunc(i,p,j,k,g,h,m): 
    return gaunt(i,i,i,p,j,k)*np.real(alm1[g])*np.real(alm1[h])*np.real(alm1[m])

def hpalm(l,i,z):
    return hp.Alm.getidx(l, i, z)

def ciM(i,p,j,k,g,h,m):
    c_i += (gauntFunc(i,p,j,k,g,h,m))
    return c_i


B_ell.append(gauntFunc(0,0,0,0,0,0,0))

for i in range(1, l+1):
        for p in range (-i, i+1):
            
                g=hpalm(l, i, abs(p))
                for j in range(-i, i+1):
                    h=hpalm(l, i, abs(j))
                    for k in range(-i, i+1):
                     c_i += ciM(i,p,j,abs(k),g,h,hpalm(l, i, abs(k)))
            
            
                for j in range(-i, i+1):
                  h=hpalm(l, i, abs(j))
                for k in range(-i, i+1):
                     c_i += ciM(i,p,j,k,g,h,m=hpalm(l, i, abs(k)))
                   
        B_ell.append(c_i)
B_ell

###########################################################################################
# Now we plot the Bl's x l, in normal scale and log scale
##############################################################################################

bl_test = B_ell
ell = np.arange(len(bl_test))
#bl_testl = (ell * (ell + 1) * bl_test / (2*pi))



plt.rcParams['figure.figsize'] = (12,8)

plt.xlabel('$\ell$')
plt.ylabel('$B_\ell$')
plt.plot(ell, bl_test)
plt.savefig('Bispectrum_HI.png')

plt.rcParams['figure.figsize'] = (12,8)

plt.xlabel('$\ell$')
plt.ylabel('$B_\ell$')
plt.plot(ell, bl_test)
plt.xscale('log')
plt.savefig('Bispectrum_HI_log.png')

