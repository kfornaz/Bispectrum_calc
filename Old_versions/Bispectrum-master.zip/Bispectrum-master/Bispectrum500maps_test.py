###########################################################################

from scipy.integrate import quad
from scipy.interpolate import interp1d
from scipy.stats import norm
import matplotlib
import numpy as np
import healpy as hp
import matplotlib.pyplot as plt
import matplotlib.cm as cm
import matplotlib.mlab as mlab
from astropy.io import fits
from math import pi, sin, cos, sqrt, log, floor
from sympy.physics.wigner import gaunt

###################################################################################

def gauntB(l1, l2, l3, m1, m2, m3, p1, p2, p3):
    b_ell = gaunt(l1,l2,l3,m1,m2,m3)*np.real(alm1[p1]*alm2[p2]*alm3[p3])
    return b_ell

def alm_position(lmax, la, ma):
    alm_position = hp.Alm.getidx(lmax, la, ma)
    return alm_position

####################################################################################
B_elltotal = np.zeros((500,31))
for i in range(0, 500):
    NSIDE = 64
    mu, sigma = 0, 0.1 # mean and standard deviation
    mapa = np.random.normal(mu, sigma, hp.nside2npix(NSIDE))

###################################################################################

    B_ell=[]
    lmax=30
    alm1 = hp.map2alm(mapa)
    alm2 = hp.map2alm(mapa)
    alm3 = hp.map2alm(mapa)
    sum = 0

##################################################################################

    l1 = 0
    l2 = 0
    l3 = 0

    for l1 in range(0, lmax+1):
        l2 = l1
        l3 = l1
        for m1 in range(-l1, l1+1):
            p1 = alm_position(lmax, l1, abs(m1))
            for m2 in range(-l1, l1+1):
                p2 = alm_position(lmax, l1, abs(m2))
                for m3 in range(-l1, l1+1):
                    p3 = alm_position(lmax, l1, abs(m3))
                    sum += gauntB(l1, l2, l3, m1, m2, m3, p1, p2, p3)
        B_ell.append(sum)
        sum = 0
    B_elltotal[i,:] = B_ell

    bl_test = B_ell
    ell = np.arange(len(bl_test))

    plt.rcParams['figure.figsize'] = (12,8)
    plt.xlabel('$\ell$')
    plt.ylabel('$B_\ell$')
    plt.plot(ell, bl_test)
    plt.savefig('Bispectrum_TNV30.png')
    
    plt.rcParams['figure.figsize'] = (12,8) 
    plt.xlabel('$\ell$')
    plt.ylabel('$B_\ell$')
    plt.plot(ell, bl_test)
    plt.xscale('log')
    plt.savefig('Bispectrum_TN_logV30.png')


####################################################################################
for i in range(0, 500):
    mean=np.mean(B_elltotal[i,:], dtype=np.float64)
    print "mean_map ==", mean
    std=np.std(B_elltotal[i,:], dtype=np.float64)
    print "std_map ==", std



